var speed = 500;
var games = 0;

//game parts
var board = [];
var length = 17
for (var i = 0 ; i < length ; i++) {
    var x = [];
    for (var j = 0 ; j < length ; j++) {
        x.push(0);
    }
    board.push(x)
}

var cnt = 0
var html = "<table>";
for (var i = 0 ; i < board.length ; i++) {
    html += "<tr>";
    for (var j = 0 ; j < board[i].length ; j++) {
        html += "<td class='button' style='height:10px;width:10px;' id='" + cnt  +"'>O</td>";
        cnt++;
    }
    html += "</tr>";
}
html += "</table>";

$("body").html(html)


$('.button').click(function() {
    sendData({
        type: "play",
        cnt: $(this).attr('id'),
        team: team
    })
});

var team;
var connection;

$(document).ready(function() {
    startConnection();
});

function startConnection() {
    var socket = window.WebSocket || window.MozWebSocket;
    var loc = window.location, new_uri;
    if (loc.protocol === "https:") {
        new_uri = "wss:";
    } else {
        new_uri = "ws:";
    }
    var gameId = loc.pathname.substring(1);
    new_uri += "//" + loc.host + "/websocket?game=" + 0;
    connection = new socket(new_uri);
    connection.onerror = function (error) {
        console.log(error);
    };

    connection.onclose = function () {
        var message = "Connection to server closed";
        $("body").append("<div id='msg'>" + message + "</div>");
        var leftOffset = ($("body").innerWidth() - $("#msg").outerWidth())/2;
        var topOffset = ($("body").innerHeight() - $("#msg").outerHeight())/2;
        $("#msg").css("left",leftOffset).css("top",topOffset);
    };

    connection.onmessage = function (message) {
        var data = JSON.parse(message.data);
        console.log(data);
        switch (data.type) {
        case "start":
            team = data.team;
            break;
        case "play":
            if (data.team === undefined) {
                alert("something went very wrong");
            } else {
                var pos = data.pos;
                $("#" + data.cnt).html(data.team == 1 ? 'X' : 'H')
            }
            break;
        case "endGame":
            break;
        case "newGame":
            break;
        }
    };
}

function playData(player,result) {
    sendData({type:"play",player:player,result:result});
}

function sendNewGame(player,result) {
    sendData({type:"start"});
}

function sendData(data) {
    connection.send(JSON.stringify(data));
}

function getPercentage(num,den) {
    return num + " (" + ((num/den)*100).toFixed(2) + "%)";
}