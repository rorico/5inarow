modules.exports = function() {
    
var board = [];
var length = 15
for (var i = 0 ; i < length ; i++) {
    var x = [];
    for (var j = 0 ; j < length ; j++) {
        x.push(0);
    }
    board.push(x)
}
listeners = [];
var id = 0;

}